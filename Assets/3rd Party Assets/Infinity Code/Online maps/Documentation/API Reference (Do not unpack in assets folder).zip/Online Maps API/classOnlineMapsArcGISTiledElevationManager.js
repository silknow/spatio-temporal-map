var classOnlineMapsArcGISTiledElevationManager =
[
    [ "StartDownloadElevationTile", "classOnlineMapsArcGISTiledElevationManager.html#aab29e7b3e3ddbc95a72392c07947da64", null ],
    [ "resolution", "classOnlineMapsArcGISTiledElevationManager.html#accddbeb87e0d3f127659172884238430", null ]
];