var classOnlineMapsGoogleDirectionsResult_1_1Leg =
[
    [ "arrival_time", "classOnlineMapsGoogleDirectionsResult_1_1Leg.html#a2229e9e08d4ffc2cf75d78e991fcb59f", null ],
    [ "departure_time", "classOnlineMapsGoogleDirectionsResult_1_1Leg.html#a692d79e4afa205cd8f312523fda1e32d", null ],
    [ "distance", "classOnlineMapsGoogleDirectionsResult_1_1Leg.html#a0cea5daf940ffcb6fedf27cd3d3a13da", null ],
    [ "duration", "classOnlineMapsGoogleDirectionsResult_1_1Leg.html#a2533df87459c0fce6573c0a1d2c07da1", null ],
    [ "duration_in_traffic", "classOnlineMapsGoogleDirectionsResult_1_1Leg.html#a183b80bac205b043b947aa679e8186f6", null ],
    [ "end_address", "classOnlineMapsGoogleDirectionsResult_1_1Leg.html#ac9ebb53e79d7b572fbc083f3fea7810a", null ],
    [ "end_location", "classOnlineMapsGoogleDirectionsResult_1_1Leg.html#a3ed135967ad8106d5854ca8126098f62", null ],
    [ "start_address", "classOnlineMapsGoogleDirectionsResult_1_1Leg.html#a3918bc373ffc5c8f01a3c5a6d2ee6bc3", null ],
    [ "start_location", "classOnlineMapsGoogleDirectionsResult_1_1Leg.html#a4c930a63b2777642f4dc226756dc3df6", null ],
    [ "steps", "classOnlineMapsGoogleDirectionsResult_1_1Leg.html#a6cc3fd94060bab2e486226b2814088d8", null ]
];