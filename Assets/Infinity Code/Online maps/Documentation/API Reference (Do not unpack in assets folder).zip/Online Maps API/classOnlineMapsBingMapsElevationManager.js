var classOnlineMapsBingMapsElevationManager =
[
    [ "StartDownloadElevation", "classOnlineMapsBingMapsElevationManager.html#a3d2be33196afb5e7d6f98a98a6d67ef1", null ],
    [ "bingAPI", "classOnlineMapsBingMapsElevationManager.html#a2de1bf12fddbe5a1ce822d25bf7e9de2", null ]
];